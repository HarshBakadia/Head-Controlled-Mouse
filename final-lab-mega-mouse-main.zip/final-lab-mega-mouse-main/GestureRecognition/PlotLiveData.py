import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import numpy as np
import sys
import serial

PORT = "COM3"
N = 25


if __name__ == "__main__":

   
    serialPort = serial.Serial(port = PORT, baudrate=115200,
                           bytesize=8, timeout=2, stopbits=serial.STOPBITS_ONE)

    serialString = ""

   
    
    plt.ion()
    fig, axs = plt.subplots(2,3)

    plot_acc_x = np.array([])
    plot_acc_y = np.array([])
    plot_acc_z = np.array([])
    plot_gyro_x = np.array([])
    plot_gyro_y = np.array([])
    plot_gyro_z = np.array([])
    
    
    while(True):
        
        if(serialPort.in_waiting > 0):
            serialString = serialPort.readline().decode('Ascii')
            
            stringArray = serialString[:-2].split(" ")
            hexDigits = [elem[-4:] for elem in stringArray]
            
            acc_x = np.int16(int(hexDigits[0],16))
            acc_y = np.int16(int(hexDigits[1],16))
            acc_z = np.int16(int(hexDigits[2],16))

            gyro_x = np.int16(int(hexDigits[3],16))
            gyro_y = np.int16(int(hexDigits[4],16))
            gyro_z = np.int16(int(hexDigits[5],16))
            
            plot_acc_x = np.append(plot_acc_x[-N:],acc_x);
            plot_acc_y = np.append(plot_acc_y[-N:],acc_y);
            plot_acc_z = np.append(plot_acc_z[-N:],acc_z);

            plot_gyro_x = np.append(plot_gyro_x[-N:],gyro_x);
            plot_gyro_y = np.append(plot_gyro_y[-N:],gyro_y);
            plot_gyro_z = np.append(plot_gyro_z[-N:],gyro_z);

            print("\nAccelerometer X: %d Y: %d Z: %d" % (acc_x, acc_y, acc_z));
            print("Gyroscope X: %d Y: %d Z: %d\n" % (gyro_x,gyro_y, gyro_z));


          
            axs[0][0].set_title("Accelerometer Y");
            axs[0][1].set_title("Accelerometer Y");
            axs[0][2].set_title("Accelerometer Z");

            axs[1][0].set_title("Gyroscope X");
            axs[1][1].set_title("Gyroscope Y");
            axs[1][2].set_title("Gyroscope Z");

            axs[0][0].set_ylim(-32768,32768);
            axs[0][1].set_ylim(-32768,32768);
            axs[0][2].set_ylim(-32768,32768);
            axs[1][0].set_ylim(-32768,32768);
            axs[1][1].set_ylim(-32768,32768);
            axs[1][2].set_ylim(-32768,32768);

            axs[0][0].plot(plot_acc_x)
            axs[0][1].plot(plot_acc_y)
            axs[0][2].plot(plot_acc_z)

            axs[1][0].plot(plot_gyro_x)
            axs[1][1].plot(plot_gyro_y)
            axs[1][2].plot(plot_gyro_z)

            plt.pause(0.0000005)
            axs[0][0].clear()
            axs[0][1].clear()
            axs[0][2].clear()
            axs[1][0].clear()
            axs[1][1].clear()
            axs[1][2].clear()

            
            #plt.show()
            # print("%f %f %f" % (acc_x, acc_y, acc_z));

           