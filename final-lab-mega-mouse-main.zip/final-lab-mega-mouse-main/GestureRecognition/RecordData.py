import numpy as np
import matplotlib.pyplot as plt
import serial
import calendar
import time

PORT = "COM3"
maxSamples = 25

# feature_labels = np.array(["TIME","ACC_X",'ACC_Y','ACC_Z','GYRO_X','GYRO_Y','GYRO_Z'])
# classNames = np.array(['REST','UP','DOWN','LEFT','RIGHT'])

currentGesture = 0;
finished = False



while not finished:
    gestName = input("Enter Gesture Name: ")
    print("Current Gesture: %s" % gestName)

    recordGesture = ""

    while recordGesture != "y":
        numSamples = 0;
        data = np.empty((0, 7), np.int16)

        serialPort = serial.Serial(port = PORT, baudrate=115200,
                           bytesize=8, timeout=2, stopbits=serial.STOPBITS_ONE)
        serialString = ""

        while(numSamples < maxSamples):
            if serialPort.in_waiting > 0:
                serialString = serialPort.readline().decode('Ascii')
                
                stringArray = serialString[:-2].split(" ")
                hexDigits = [elem[-4:] for elem in stringArray]
                
                acc_x = np.int16(int(hexDigits[0],16))
                acc_y = np.int16(int(hexDigits[1],16))
                acc_z = np.int16(int(hexDigits[2],16))

                gyro_x = np.int16(int(hexDigits[3],16))
                gyro_y = np.int16(int(hexDigits[4],16))
                gyro_z = np.int16(int(hexDigits[5],16))

                sample = np.array([[numSamples, acc_x, acc_y, acc_z, gyro_x, gyro_y, gyro_z]])
             
                numSamples = numSamples + 1;
                print("\t %d" % numSamples)
                # print(sample)
                data = np.append(data,sample,axis=0)

        serialPort.close()

        print(data)
        fig, axs = plt.subplots(2,3)

        axs[0][0].set_title("Accelerometer X");
        axs[0][1].set_title("Accelerometer Y");
        axs[0][2].set_title("Accelerometer Z");

        axs[1][0].set_title("Gyroscope X");
        axs[1][1].set_title("Gyroscope Y");
        axs[1][2].set_title("Gyroscope Z");

        axs[0][0].set_ylim(-32768,32768);
        axs[0][1].set_ylim(-32768,32768);
        axs[0][2].set_ylim(-32768,32768);
        axs[1][0].set_ylim(-32768,32768);
        axs[1][1].set_ylim(-32768,32768);
        axs[1][2].set_ylim(-32768,32768);


        axs[0][0].plot(data[:,1])
        axs[0][1].plot(data[:,2])
        axs[0][2].plot(data[:,3])

        axs[1][0].plot(data[:,4])
        axs[1][1].plot(data[:,5])
        axs[1][2].plot(data[:,6])

     


        plt.show()
        
        discard = input("\tSave? (y/n): ")

        if(discard == 'y'):
            current_GMT = time.gmtime()
            ts = calendar.timegm(current_GMT)

            fileName = gestName+"_"+str(ts)+".csv";

            np.savetxt(str("data_"+fileName), data, delimiter=",")
            # np.savetxt(str("labels_"+fileName), feature_labels,delimiter=",")

        recordGesture = input("\tExit ? (y/n): ")
    
