from sklearn import tree
import numpy as np
import matplotlib.pyplot as plt
import os


arr = np.empty((0, 7), np.int16)

features = ["ACC_X","ACC_Y","ACC_Z","GYRO_X","GYRO_Y","GYRO_Z"]
# directories = ["Gestures/Down","Gestures/Up","Gestures/Left","Gestures/Right","Gestures/Rest"]
directories = ["Gestures/Up","Gestures/Rest"]
labelNames = ["Up","Rest"]
# labelNames = ["Down", "Up", "Left", "Right","Rest"]
label = 0;

for dirName in directories:
    for filename in os.listdir(dirName):
        f = os.path.join(dirName,filename)
        arr = np.loadtxt(f,
                 delimiter=",", dtype=np.int16)
        
        fig, axs = plt.subplots(2,3)

        fig.suptitle(f);
        axs[0][0].set_title("Accelerometer X");
        axs[0][1].set_title("Accelerometer Y");
        axs[0][2].set_title("Accelerometer Z");

        axs[1][0].set_title("Gyroscope X");
        axs[1][1].set_title("Gyroscope Y");
        axs[1][2].set_title("Gyroscope Z");

        axs[0][0].set_ylim(-32768,32768);
        axs[0][1].set_ylim(-32768,32768);
        axs[0][2].set_ylim(-32768,32768);
        axs[1][0].set_ylim(-32768,32768);
        axs[1][1].set_ylim(-32768,32768);
        axs[1][2].set_ylim(-32768,32768);


        axs[0][0].plot(arr[:,0],arr[:,1])
        axs[0][1].plot(arr[:,0],arr[:,2])
        axs[0][2].plot(arr[:,0],arr[:,3])

        axs[1][0].plot(arr[:,0],arr[:,4])
        axs[1][1].plot(arr[:,0],arr[:,5])
        axs[1][2].plot(arr[:,0],arr[:,6])

        # plt.show()

    label = label + 1;