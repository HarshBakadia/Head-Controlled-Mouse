from sklearn import tree
import numpy as np
import graphviz
import os
import serial
from sklearn.linear_model import Perceptron


PORT = "COM3"



features = ["ACC_X","ACC_Y","ACC_Z","GYRO_X","GYRO_Y","GYRO_Z"]

data = np.empty((0, 7), np.int16)
dataLabels = np.array([],np.int32)
directories = ["Gestures/Up","Gestures/Rest"]
labelNames = ["Up","Rest"]
label = 0;
for dirName in directories:
    for filename in os.listdir(dirName):
        f = os.path.join(dirName,filename)
        arr = np.loadtxt(f,
                 delimiter=",", dtype=np.int16)
        labelArray = np.full(arr.shape[0], label)

        data = np.append(data, arr, axis=0)
        dataLabels = np.append(dataLabels, labelArray)

    label = label + 1;

data = np.delete(data, np.s_[0], axis=1);

# clf = tree.DecisionTreeClassifier()
# clf = clf.fit(data[:],dataLabels[:])

percept = Perceptron(random_state=42);
percept.fit(data,dataLabels)
print(percept.coef_)
# graphData = tree.export_graphviz(clf, out_file=None, feature_names=features,class_names=labelNames,filled=True, rounded=True,special_characters=True)
# graph = graphviz.Source(graphData)



# graph.render("decisionTree")
serialPort = serial.Serial(port = PORT, baudrate=115200,
                           bytesize=8, timeout=2, stopbits=serial.STOPBITS_ONE)

serialString = ""
while(True):
        
        if(serialPort.in_waiting > 0):
            serialString = serialPort.readline().decode('Ascii')
            
            stringArray = serialString[:-2].split(" ")
            hexDigits = [elem[-4:] for elem in stringArray]
            
            acc_x = np.int16(int(hexDigits[0],16))
            acc_y = np.int16(int(hexDigits[1],16))
            acc_z = np.int16(int(hexDigits[2],16))

            gyro_x = np.int16(int(hexDigits[3],16))
            gyro_y = np.int16(int(hexDigits[4],16))
            gyro_z = np.int16(int(hexDigits[5],16))

            print("Neuron: %s" % labelNames[percept.predict([[acc_x,acc_y,acc_z,gyro_x,gyro_y,gyro_z]])[0]])
            # print(labelNames[clf.predict([[acc_x,acc_y,acc_z,gyro_x,gyro_y,gyro_z]])[0]])

# graph
            
# print(arr)
# print(arr2)

# arr = np.append(arr,arr2,axis=0);
# print(arr)