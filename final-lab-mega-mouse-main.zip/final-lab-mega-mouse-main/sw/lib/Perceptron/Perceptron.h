/**
 * @file Perceptron.h
 * @author Aeybel Varghese (aeybelvarghese@gmail.com)
 * @brief Implementation of a Perceptron Neuron in C
 * @version 0.1
 * @date 2022-11-30
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdint.h>

/**
 * @brief Predicts the gesture based on recorded IMU measurements
 *
 * @param input array of accelerometer and gyyoscope measurement
 * @param output output array yielding 0 or 1 for the gesture it detects
 */
void predict(int16_t* input, uint8_t* output);

/**
 * @brief Perceptron algorithm, performs weighted sum
 *
 * @param input input array to perform multiplication
 * @param weightRow index of row in array of weights
 */
long weightedSum(int16_t* input, uint8_t weightRow);

/**
 * @brief Writes to a register in the LSM6DSO
 *
 * @param value value to perform step function
 */
uint8_t stepFunction(long value);
