#include "Perceptron.h"

// Weights from neural network
long weights[][7] = {
    //"ACC_X","ACC_Y","ACC_Z","GYRO_X","GYRO_Y","GYRO_Z"
    {16236.,  9533.,  -715., 10459., 87354.,  1903.}, // down
    {9428., -27736.,   4378., -67563.,  13059.,   8912.}, // left
    {15559., 67612., 44831., 84091., 12276., -3946.}, // right
    {18603.,  50171., -14577., -14633., -89115.,   -544.} // up
};

void predict(int16_t* input, uint8_t* output){
    output[0] = stepFunction(weightedSum(input, 0));
    output[1] = stepFunction(weightedSum(input,1));
    output[2] = stepFunction(weightedSum(input, 2));
    output[3] = stepFunction(weightedSum(input, 3));
}

long weightedSum(int16_t* input, uint8_t weightRow){
    long sum = 0;
    for(int i = 0; i < 6; i++){
        sum += input[i] * weights[weightRow][i];
    }
    return sum;
}

uint8_t stepFunction(long value){
    if(value > 0) return 1;
    else return 0;   
}
