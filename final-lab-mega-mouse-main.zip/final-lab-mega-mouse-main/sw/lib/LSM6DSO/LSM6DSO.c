/**
 * @file LSM6DSO.c
 * @author Aeybel Varghese (aeybelvarghese@gmail.com)
 * @brief Library for the LSM6DSO inertial module from STMicroelectronics to work with the TM4C via SPI
 * @version 0.1
 * @date 2022-10-26
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/** Pin connections: */
// This library uses connection on Port D with SSI3.
// For our project we used the SparkFun 6 Degrees of Freedom Breakout Board - LSM6DSO (Qwiic)
// Refer to the data sheet as to the pin connections on the IC and the 4 modes that are possible for pin configurations
// The pin mapping below uses the SparkFun breakout board and its pin mode
//
//  LSM6DSO     TM4C    Desc
//
//  SDA/SDI     PD3     SSI3Tx, Output from the TM4C to the device data in on the LSM6DSO. Commands are sent via this (MOSI)
//  SDO         PD2     SSI3Rx, Output from the LSM6DSO to the TM4C, contains readings from the LSM6DSO (MISO)
//  CS          PD1     SSI3Fss, Chip select, setting it low selects the device (!CS)
//  SCL         PD0     SSI3Clk, Serial clock

#include "LSM6DSO.h"
#include "./inc/tm4c123gh6pm.h"

#define PD1                     (*((volatile uint32_t *)0x40007008))
#define PF1                     (*((volatile uint32_t *)0x40025008))

void DelayWait10ms(uint32_t n) {
    uint32_t volatile time;
    while (n){
        time = 727240 * 2 / 91;  // 10msec
        while (time){
            --time;
        }
        --n;
    }
}

void LSM6DSO_Init(void){
    
    SYSCTL_RCGCSSI_R |= 0x08;                                                   // Activate SSI3
    SYSCTL_RCGCGPIO_R |= 0x08;                                                  // Activate Port D

    while((SYSCTL_PRGPIO_R & 0x08) == 0){}                                      // Wait till stabilized

    GPIO_PORTD_AMSEL_R = 0;                                                     // Disable analog functionality on Port D
    GPIO_PORTD_PCTL_R = 0;
    GPIO_PORTD_PCTL_R = (GPIO_PORTD_PCTL_R&0xFFFF00F0) + 0x00001101;            // SSI3 on PD0-3
    GPIO_PORTD_DIR_R |= 0x02;                                                   // PD1 (CS) as output
    GPIO_PORTD_AFSEL_R = 0;
    GPIO_PORTD_AFSEL_R |= 0x0D;                                                 // Alt-function on PD0-3
    GPIO_PORTD_DEN_R |= 0x0F;                                                   // Enable digital for SSI
    PD1 = 0x02;

    SSI3_CR1_R = 0;                                                             // Disable SSI3
    SSI3_CPSR_R = 0x0A;                                                         // F_SSI = F_BUS / (CPSDVSR * (1+SCR)) = 80 MHz / (10 * 1+0) = 80MHz / 10 = 8MHz. LSM6DSO has max SPI clock freq of 10MHz, I go with 8MHz
    SSI3_CR0_R = 0;
    SSI3_CR0_R |= 0xC0;                                                         // SCR = 0, SPH = 1, SPO = 0
    SSI3_CR0_R = (SSI3_CR0_R&~SSI_CR0_DSS_M)+SSI_CR0_DSS_16;                    // 8 bit data

    SSI3_CR1_R |= SSI_CR1_SSE;                                                  // Enable SSI
    
}


uint8_t LSM6DSO_Transfer(uint8_t data){
    uint16_t output = ((uint16_t) data) << 8;
    PD1 = 0x00;
    while((SSI3_SR_R&SSI_SR_TFE) == 0){}                                        // Waits til transmit FIFO empty
    SSI3_DR_R = output;                                     // Transmits
    while((SSI3_SR_R&SSI_SR_RNE) == 0){}                                        // Waits till receive reply
    uint8_t reply = SSI3_DR_R;
    PD1 = 0x02;
    return reply;
}

void LSM6DSO_ReadRegister(uint8_t* output, uint8_t address){
   
    *output = LSM6DSO_Transfer(address | LSM6DSO_READ_COMMAND);                 // Sends byte to the LSM6DS0 with the RW set to read register, the reply is the following byte which is stored in output
    
}

void LSM6DSO_WriteRegister(uint8_t address, uint8_t data){
    PD1 = 0x00;
    uint16_t command = (((uint16_t) address << 8) + data) & LSM6DSO_WRITE_COMMAND;
    while((SSI3_SR_R&SSI_SR_TFE) == 0){}                                        // Waits til transmit FIFO empty
    SSI3_DR_R = command; 
    while((SSI3_SR_R&SSI_SR_RNE) == 0){}                                        // Waits till receive reply
    uint8_t discard = SSI3_DR_R;
    PD1 = 0x02;
}

void LSM6DSO_StartAccelerometer(uint8_t ODR){
    LSM6DSO_WriteRegister(LSM6DSO_CTRL1_XL_R,ODR);
}

void LSM6DSO_StartGyroscope(uint8_t ODR){
    LSM6DSO_WriteRegister(LSM6DSO_CTRL2_G_R,ODR);
}

void LSM6DSO_PollGyroscope(LSM6DSO_Data* output){
		PF1 ^= 0x02;
    uint8_t status;
    LSM6DSO_ReadRegister(&status,LSM6DSO_STATUS_REG_R);
    // if(status & 0x01){
        uint8_t x_l;
        uint8_t x_h;
        uint8_t y_l;
        uint8_t y_h;
        uint8_t z_l;
        uint8_t z_h;

        DelayWait10ms(1);
        LSM6DSO_ReadRegister(&x_l,LSM6DSO_OUTX_L_G_R);
        LSM6DSO_ReadRegister(&x_h,LSM6DSO_OUTX_H_G_R);

        LSM6DSO_ReadRegister(&y_l,LSM6DSO_OUTY_L_G_R);
        DelayWait10ms(1);
        LSM6DSO_ReadRegister(&y_h,LSM6DSO_OUTY_H_G_R);
        DelayWait10ms(1);

        LSM6DSO_ReadRegister(&z_l,LSM6DSO_OUTZ_L_G_R);
        DelayWait10ms(1);
        LSM6DSO_ReadRegister(&z_h,LSM6DSO_OUTZ_H_G_R);
        DelayWait10ms(1);

        output->gyro_x = ((uint16_t) x_h << 8) | x_l;
        output->gyro_y = ((uint16_t) y_h << 8) | y_l;
        output->gyro_z = ((uint16_t) z_h << 8) | z_l;
    // }
		PF1 ^= 0x02;
}

void LSM6DSO_PollAccelerometer(LSM6DSO_Data* output){
    uint8_t status;
    LSM6DSO_ReadRegister(&status,LSM6DSO_STATUS_REG_R);
    // if(status & 0x02){
        uint8_t x_l;
        uint8_t x_h;
        uint8_t y_l;
        uint8_t y_h;
        uint8_t z_l;
        uint8_t z_h;

        DelayWait10ms(1);
        LSM6DSO_ReadRegister(&x_l,LSM6DSO_OUTX_L_A_R);
        DelayWait10ms(1);
        LSM6DSO_ReadRegister(&x_h,LSM6DSO_OUTX_H_A_R);
        DelayWait10ms(1);
        
        LSM6DSO_ReadRegister(&y_l,LSM6DSO_OUTY_L_A_R);
        DelayWait10ms(1);
        LSM6DSO_ReadRegister(&y_h,LSM6DSO_OUTY_H_A_R);
        DelayWait10ms(1);

        LSM6DSO_ReadRegister(&z_l,LSM6DSO_OUTZ_L_A_R);
        DelayWait10ms(1);
        LSM6DSO_ReadRegister(&z_h,LSM6DSO_OUTZ_H_A_R);
        DelayWait10ms(1);

        output->acc_x = ((uint16_t) x_h << 8) | x_l;
        output->acc_y = ((uint16_t) y_h << 8) | y_l;
        output->acc_z = ((uint16_t) z_h << 8) | z_l;

 
    // }
}
