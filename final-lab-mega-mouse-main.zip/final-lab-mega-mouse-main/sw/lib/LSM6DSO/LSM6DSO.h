/**
 * @file LSM6DSO.h
 * @author Aeybel Varghese (aeybelvarghese@gmail.com)
 * @brief Library for the LSM6DSO inertial module from STMicroelectronics to work with the TM4C via SPI
 * @version 0.1
 * @date 2022-10-26
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/** Pin connections: */
// This library uses connection on Port D with SSI3.
// For our project we used the SparkFun 6 Degrees of Freedom Breakout Board - LSM6DSO (Qwiic)
// Refer to the data sheet as to the pin connections on the IC and the 4 modes that are possible for pin configurations
// The pin mapping below uses the SparkFun breakout board and its pin mode
//
//  LSM6DSO     TM4C    Desc
//
//  SDA/SDI     PD3     SSI3Tx, Output from the TM4C to the device data in on the LSM6DSO. Commands are sent via this (MOSI)
//  SDO         PD2     SSI3Rx, Output from the LSM6DSO to the TM4C, contains readings from the LSM6DSO (MISO)
//  CS          PD1     SSI3Fss, Chip select, setting it low selects the device (!CS)
//  SCL         PD0     SSI3Clk, Serial clock


#pragma once

// Includes
#include <stdint.h>

// Library defines
#define POWER_GYROSCOPE_NORMAL          0x00
#define POWER_GYROSCOPE_LOW             0x01
#define POWER_ACCELEROMETER_NORMAL      0x00
#define POWER_ACCELEROMETER_LOW         0x01
#define POWER_ACCELEROMETER_ULTRA_LOW   0x02
#define ODR_HIGH_PERFORMANCE            0x60
#define ODR_ULTRA_LOW_POWER             0x20

// Register defintions 
#define LSM6DSO_WHO_AM_I_R              (uint8_t) 0x0F
#define LSM6DSO_CTRL1_XL_R              (uint8_t) 0x10
#define LSM6DSO_CTRL2_G_R               (uint8_t) 0x11
#define LSM6DSO_STATUS_REG_R            (uint8_t) 0x1E
#define LSM6DSO_OUTX_L_G_R              (uint8_t) 0x22 
#define LSM6DSO_OUTX_H_G_R              (uint8_t) 0x23
#define LSM6DSO_OUTY_L_G_R              (uint8_t) 0x24
#define LSM6DSO_OUTY_H_G_R              (uint8_t) 0x25
#define LSM6DSO_OUTZ_L_G_R              (uint8_t) 0x26
#define LSM6DSO_OUTZ_H_G_R              (uint8_t) 0x27
#define LSM6DSO_OUTX_L_A_R              (uint8_t) 0x28
#define LSM6DSO_OUTX_H_A_R              (uint8_t) 0x29
#define LSM6DSO_OUTY_L_A_R              (uint8_t) 0x2A
#define LSM6DSO_OUTY_H_A_R              (uint8_t) 0x2B
#define LSM6DSO_OUTZ_L_A_R              (uint8_t) 0x2C
#define LSM6DSO_OUTZ_H_A_R              (uint8_t) 0x2D

// Commands
#define LSM6DSO_READ_COMMAND            0x80
#define LSM6DSO_WRITE_COMMAND           0x7FFF

typedef struct LSM6DSO_Data{
    int16_t acc_x;
    int16_t acc_y;
    int16_t acc_z;
    int16_t gyro_x;
    int16_t gyro_y;
    int16_t gyro_z;
} LSM6DSO_Data;

/**
 * @brief Initializes LSM6DSO SPI communication
 * 
 */
void LSM6DSO_Init(void);

/**
 * @brief Transfer byte data to the LSM6DSO, returns the reply
 * 
 * @param data Data to send to the LSM6DSO
 * @return uint8_t reply from LSM6DSO
 */
uint8_t LSM6DSO_Transfer(uint8_t data);

/**
 * @brief Reads a register from the LSM6DSO (8 bit data)
 * 
 * @param output pointer to the variable that will hold the data read from the register 
 * @param address LSM6DSO register to read
 */
void LSM6DSO_ReadRegister(uint8_t* output, uint8_t address);

/**
 * @brief Reads a register from the LSM6DSO (16 bit data)
 * 
 * @param output pointer to the 16-bit variable that will hold the data read from the register 
 * @param address LSM6DSO register to read
 */
void LSM6DSO_ReadRegister16(uint16_t* output, uint8_t address);

/**
 * @brief Writes to a register in the LSM6DSO
 * 
 * @param address LSM6DSO register to write to
 * @param data data to write to register
 */
void LSM6DSO_WriteRegister(uint8_t address, uint8_t data);

/**
 * @brief Starts the Gyroscope on the LSM6DSO
 * 
 * @param ODR ODR rate
 */
void LSM6DSO_StartGyroscope(uint8_t ODR);

/**
 * @brief Starts accelerometer
 * 
 * @param ODR ODR rate
 */
void LSM6DSO_StartAccelerometer(uint8_t ODR);

/**
 * @brief Polls the LSM6DSO for gyroscope measurements
 * 
 * @param output data struct to store data
 */
void LSM6DSO_PollGyroscope(LSM6DSO_Data* output);

/**
 * @brief Polls the LSM6DSO for accelerometer measurements
 * 
 * @param output data struct to store data
 */
void LSM6DSO_PollAccelerometer(LSM6DSO_Data* output);

/**
 * @brief Enables the FSM engine on the LSM6DSO to offload gesture processing to the IC
 * 
 */
void LSM6DSO_StartFSMEngine();

/**
 * @brief Programs the FMS for each gesture to the LSM6DSO, sets up interrupts
 * 
 */
void LSM6DSO_ProgramFSM();

/**
 * @brief Interrupt handler when the LSM6DSO sends a interrupt, set up during LSM6DSO_ProgramFSM()
 * 
 */
void LSM6DSO_InterruptHandler();

/**
 * @brief Sets the power mode of the Accelerometer
 * 
 * @param mode power mode
 */
void LSM6DSO_SetAccelerometerPowerMode(uint8_t mode);

/**
 * @brief Sets the power mode for the Gyroscope
 * 
 * @param mode 
 */
void LSM6DSO_SetGyroscopePowerMode(uint8_t mode);

