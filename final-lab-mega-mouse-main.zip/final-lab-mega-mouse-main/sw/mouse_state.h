#pragma once
#include <stdint.h>

int8_t* getPredictions();

void setPredictions(int8_t* predictions);
