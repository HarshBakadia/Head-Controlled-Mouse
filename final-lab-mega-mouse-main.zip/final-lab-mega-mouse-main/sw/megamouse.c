// Team Mega Mouse

// Using TI example of USB mouse, we use tivware to do USB HID. This is the USB HID Device example made by TI heavily modified with what we had written in keil due to tivaware not linkign well in keil


// Tivaware USB includes, and other Tivware includes for the overall system and UART
#include <stdio.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "remoti_uart.h"
#include "drivers/buttons.h"
#include "usblib/usblib.h"
#include "usblib/usbhid.h"
#include "usblib/device/usbdevice.h"
#include "usblib/device/usbdcomp.h"
#include "usblib/device/usbdhid.h"
#include "usblib/device/usbdhidmouse.h"
#include "usblib/device/usbdhidkeyb.h"
#include "events.h"
#include "usb_structs.h"


#include <stdint.h>
#include "lib/LSM6DSO/LSM6DSO.h"
#include "lib/Perceptron/Perceptron.h"
#include "mouse_state.h"


// Tiva ware event bits
volatile uint_fast32_t g_ui32Events;

// Left click and right click button status
volatile uint_fast8_t g_ui8Buttons;


// Systick counter

volatile uint_fast32_t g_ui32SysTickCount;


// USB Composite Descriptor
#define DESCRIPTOR_DATA_SIZE    (COMPOSITE_DHID_SIZE + COMPOSITE_DHID_SIZE)
uint8_t g_pui8DescriptorData[DESCRIPTOR_DATA_SIZE];



// Tivaware Error Routine

#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif


// Hold readings from the sensor
LSM6DSO_Data output;

// Readings are stores in array
int16_t input[] = {0,0,0,0,0,0};

// Output of Neural Network
int8_t predictions[] = {0,0,0,0};


// Systick Handler
void SysTickIntHandler(void)
{
    // Systick handle event
    g_ui32SysTickCount++;
    HWREGBITW(&g_ui32Events, USB_TICK_EVENT) = 1;
    HWREGBITW(&g_ui32Events, LPRF_TICK_EVENT) = 1;

    // Poll measurements
    LSM6DSO_PollAccelerometer(&output);
    LSM6DSO_PollGyroscope(&output);

    // Print measurements for graphing on my PC
    //UARTprintf("%x %x %x %x %x %x\n" , output.acc_x,output.acc_y,output.acc_z,output.gyro_x,output.gyro_y,output.gyro_z);

    // Store into a array for the neural network
    input[0] = output.acc_x;
    input[1] = output.acc_y;
    input[2] = output.acc_z;
    input[3] = output.gyro_x;
    input[4] = output.gyro_y;
    input[5] = output.gyro_x;

    // Gives accelerometer and gyroscope readings to Neural Network, returns
    predict(input,predictions);

    // Prints predictions
    UARTprintf("%i %i %i %i\n" , predictions[0], predictions[1], predictions[2], predictions[3]);

    // Poll buttons
    g_ui8Buttons = ButtonsPoll(0, 0);

    // Sned  USB HID Report
    MouseMoveHandler();
}


// Tivaware USB UART
void ConfigureUART(void)
{
    // Enable port A
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);


    // Enable UART0
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
    ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    // 16mhz occilator
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);

    // 115200 baud
    UARTStdioConfig(0, 115200, 16000000);
}



int main(void)
{
    // FPU Used for predictions
    FPULazyStackingEnable();

    // 40 MHZ clock 16mhz osccilator
    ROM_SysCtlClockSet(SYSCTL_SYSDIV_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN |
                       SYSCTL_XTAL_16MHZ);

    // tivaware interrupt priorities
    ROM_IntPrioritySet(FAULT_SYSTICK, 0x20);
    ROM_IntPrioritySet(INT_UART1, 0x60);
    ROM_IntPrioritySet(INT_UART0, 0x70);
    ROM_IntPrioritySet(INT_WTIMER5B, 0x80);

    // Initialize IMU SPI
    LSM6DSO_Init();

    // USB enable data pins and configure for usb data
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    ROM_GPIOPinTypeUSBAnalog(GPIO_PORTD_BASE, GPIO_PIN_5 | GPIO_PIN_4);


    // Inits as USB HID mouse and keyboard, dont actually use keyboard but we could
    USBDHIDMouseCompositeInit(0, &g_sMouseDevice, &g_psCompDevices[0]);
    USBDHIDKeyboardCompositeInit(0, &g_sKeyboardDevice, &g_psCompDevices[1]);

    // usb device
    USBStackModeSet(0, eUSBModeForceDevice, 0);

    // USB comp init
    USBDCompositeInit(0, &g_sCompDevice, DESCRIPTOR_DATA_SIZE,
                      g_pui8DescriptorData);

    // Sets pointer to predictions array
    setPredictions(predictions);

    // UART for debugging, tivaware style
    ConfigureUART();


    UARTprintf("Starting MegaMouse\r\n");

    // Reads product ID of IMU, verify it works in debug
    uint8_t productID;

    LSM6DSO_ReadRegister(&productID, LSM6DSO_WHO_AM_I_R);
    UARTprintf("LSM6DS0 Product ID: ");
    UARTprintf("%i\n", productID);

    LSM6DSO_StartAccelerometer(ODR_ULTRA_LOW_POWER);
    LSM6DSO_StartGyroscope(ODR_ULTRA_LOW_POWER);

    // Systick interrupt, found this to be not bad of a polling rate
    ROM_SysTickPeriodSet(ROM_SysCtlClockGet() / 25);
    ROM_SysTickIntEnable();
    ROM_SysTickEnable();

    // Init buttons
    ButtonsInit();


    while(1)
    {
        // wait

    }
}
