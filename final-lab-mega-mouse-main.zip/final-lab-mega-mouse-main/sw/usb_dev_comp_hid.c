//****************************************************************************
//
// usb_dev_comp_hid.c - Routines for handling the mouse.
//
// Copyright (c) 2012-2017 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 2.1.4.178 of the EK-TM4C123GXL Firmware Package.
//
//****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "driverlib/rom_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "usblib/usblib.h"
#include "usblib/usbhid.h"
#include "usblib/device/usbdevice.h"
#include "usblib/device/usbdcomp.h"
#include "usblib/device/usbdhid.h"
#include "usblib/device/usbdhidmouse.h"
#include "usblib/device/usbdhidkeyb.h"
#include "drivers/buttons.h"
#include "usb_structs.h"
#include "events.h"
#include "mouse_state.h"
#include <stdbool.h>



//*****************************************************************************
//
// State of the buttons on previous send of a mouse packet.
//
//*****************************************************************************
uint_fast8_t g_ui8MouseButtonsPrev;

//****************************************************************************
//
// The number of system ticks to wait for each USB packet to be sent before
// we assume the host has disconnected.  The value 50 equates to half a
// second.
//
//****************************************************************************
#define MAX_SEND_DELAY          50

//****************************************************************************
//
// This enumeration holds the various states that the mouse can be in during
// normal operation.
//
//****************************************************************************
volatile enum
{
    //
    // Not configured.
    //
    MOUSE_STATE_UNCONFIGURED,

    //
    // No keys to send and not waiting on data.
    //
    MOUSE_STATE_IDLE,

    //
    // Waiting on data to be sent out.
    //
    MOUSE_STATE_SENDING
}
g_eMouseState = MOUSE_STATE_UNCONFIGURED;

//*****************************************************************************
//
// This enumeration holds the various states that the keyboard can be in during
// normal operation.
//
//*****************************************************************************
volatile enum
{
    //
    // Unconfigured.
    //
    KEYBOARD_STATE_UNCONFIGURED,

    //
    // No keys to send and not waiting on data.
    //
    KEYBOARD_STATE_IDLE,

    //
    // Waiting on data to be sent out.
    //
    KEYBOARD_STATE_SENDING
}
g_eKeyboardState = KEYBOARD_STATE_UNCONFIGURED;

//****************************************************************************
//
// This function handles notification messages from the mouse device driver.
//
//****************************************************************************
uint32_t
MouseHandler(void *pvCBData, uint32_t ui32Event,
             uint32_t ui32MsgData, void *pvMsgData)
{
    switch(ui32Event)
    {
        //
        // The USB host has connected to and configured the device.
        //
        case USB_EVENT_CONNECTED:
        {
            g_eMouseState = MOUSE_STATE_IDLE;
            HWREGBITW(&g_ui32USBFlags, FLAG_CONNECTED) = 1;


        }

        //
        // The USB host has disconnected from the device.
        //
        case USB_EVENT_DISCONNECTED:
        {
            HWREGBITW(&g_ui32USBFlags, FLAG_CONNECTED) = 0;
            g_eMouseState = MOUSE_STATE_UNCONFIGURED;

        }

        //
        // A report was sent to the host.  We are not free to send another.
        //
        case USB_EVENT_TX_COMPLETE:
        {
            g_eMouseState = MOUSE_STATE_IDLE;
            break;
        }
    }

    return(0);
}

//***************************************************************************
//
// Wait for a period of time for the state to become idle.
//
// \param ui32TimeoutTick is the number of system ticks to wait before
// declaring a timeout and returning \b false.
//
// This function polls the current keyboard state for ui32TimeoutTicks system
// ticks waiting for it to become idle.  If the state becomes idle, the
// function returns true.  If it ui32TimeoutTicks occur prior to the state
// becoming idle, false is returned to indicate a timeout.
//
// \return Returns \b true on success or \b false on timeout.
//
//***************************************************************************
bool
MouseWaitForSendIdle(uint32_t ui32TimeoutTicks)
{
    uint32_t ui32Start;
    uint32_t ui32Now;
    uint32_t ui32Elapsed;

    ui32Start = g_ui32SysTickCount;
    ui32Elapsed = 0;

    while(ui32Elapsed < ui32TimeoutTicks)
    {
        //
        // Is the mouse is idle, return immediately.
        //
        if(g_eMouseState == MOUSE_STATE_IDLE)
        {
            return(true);
        }

        //
        // Determine how much time has elapsed since we started waiting.  This
        // should be safe across a wrap of g_ui32SysTickCount.
        //
        ui32Now = g_ui32SysTickCount;
        ui32Elapsed = ((ui32Start < ui32Now) ? (ui32Now - ui32Start) :
                     (((uint32_t)0xFFFFFFFF - ui32Start) + ui32Now + 1));
    }

    //
    // If we get here, we timed out so return a bad return code to let the
    // caller know.
    //
    return(false);
}

bool isUp = false;
bool isDown = false;
bool isLeft = false;
bool isRight = false;
uint8_t samples = 10;

//****************************************************************************
//
// This function provides simulated movements of the mouse.
//
//****************************************************************************
void
MouseMoveHandler(void)
{
    uint32_t ui32Retcode;
    int8_t i8DeltaX = 0;
    int8_t i8DeltaY = 0;
    uint8_t ui8Buttons;
    bool bSendIt, bButtonChange;




    if((g_ui8Buttons & ALL_BUTTONS) != (g_ui8MouseButtonsPrev))
    {
        bButtonChange = true;
        g_ui8MouseButtonsPrev = g_ui8Buttons;
    }
    else
    {
        bButtonChange = false;
    }

    bSendIt = true;
    int8_t* predictions = getPredictions();
    if(samples > 0 ){
        samples--;
    }

    if(samples == 0){
        if(isUp && !predictions[0]){ // rest from up
                i8DeltaY = 0;
                isUp = false;
                isDown = false;
                samples = 10;

            }
            else if(!predictions[3] || isUp){ // go up
                i8DeltaY = -6;
                isUp = true;
                isDown = false;
            }
             // rest from down
            else if(isDown && !predictions[3]){
                  i8DeltaY = 0;
                  isDown = false;
                  isUp = false;
                  samples = 10;
            }
            else if(!predictions[0] || isDown){ // down
                  i8DeltaY = 6;
                  isUp = false;
                  isDown = true;
              }

             else if(!predictions[0] && !predictions[3] && (isDown || isUp)){ // rest vertical
               	i8DeltaY = 0;
               	isDown = false;
               	isUp = false;
               	samples = 10;
            }

             else if(isLeft && !predictions[2]){ // rest from left
                   i8DeltaX = 6;
                   isLeft = false;
                   isRight = false;
                   samples = 10;

               }
               else if(!predictions[1] || isLeft){ // go left
                   i8DeltaX = -6;
                   isLeft = true;
                   isRight = false;
               }
                // rest from Right
               else if(isRight && !predictions[1]){
                     i8DeltaX = 0;
                     isLeft = false;
                     isRight = false;
                     samples = 10;
               }
               else if(!predictions[2] || isRight){ // Right
                     i8DeltaX = 6;
                     isLeft = false;
                     isRight = true;
                 }

                else if(!predictions[1] && !predictions[2] && (isLeft || isRight)){ // rest horizontal
                   i8DeltaX = 0;
                   isLeft = false;
                   isRight = false;
                   samples = 10;
               }
    }



    if(bSendIt || bButtonChange)
    {
        //
        // Convert button presses from GPIO pin positions to mouse button bit
        // positions. Overrides Motion Button action (currently not
        // implemented).
        //
        ui8Buttons = (g_ui8Buttons & LEFT_BUTTON) >> 5;

        //
        // Tell the HID driver to send this new report.
        //

        g_eMouseState = MOUSE_STATE_SENDING;
        ui32Retcode = USBDHIDMouseStateChange((void *)&g_sMouseDevice,
                                              i8DeltaX, i8DeltaY, ui8Buttons);

        //
        // Did we schedule the report for transmission?
        //
        if(ui32Retcode == MOUSE_SUCCESS)
        {
            //
            // Wait for the host to acknowledge the transmission if all went
            // well.
            //
            if(!MouseWaitForSendIdle(MAX_SEND_DELAY))
            {
                //
                // The transmission failed, so assume the host disconnected and
                // go back to waiting for a new connection.
                //
                HWREGBITW(&g_ui32USBFlags, FLAG_CONNECTED) = 0;


            }
        }
    }
}

//*****************************************************************************
//
// Handles asynchronous events from the HID keyboard driver.
//
// \param pvCBData is the event callback pointer provided during
// USBDHIDKeyboardInit().  This is a pointer to our keyboard device structure
// (&g_sKeyboardDevice).
// \param ui32Event identifies the event we are being called back for.
// \param ui32MsgData is an event-specific value.
// \param pvMsgData is an event-specific pointer.
//
// This function is called by the HID keyboard driver to inform the application
// of particular asynchronous events related to operation of the keyboard HID
// device.
//
// \return Returns 0 in all cases.
//
//*****************************************************************************
uint32_t
KeyboardHandler(void *pvCBData, uint32_t ui32Event, uint32_t ui32MsgData,
                void *pvMsgData)
{
    switch (ui32Event)
    {
        //
        // The host has connected to us and configured the device.
        //
        case USB_EVENT_CONNECTED:
        {
            HWREGBITW(&g_ui32USBFlags, FLAG_CONNECTED) = 1;
            HWREGBITW(&g_ui32USBFlags, FLAG_SUSPENDED) = 0;
            g_eKeyboardState = KEYBOARD_STATE_IDLE;


        }

        //
        // The host has disconnected from us.
        //
        case USB_EVENT_DISCONNECTED:
        {
            HWREGBITW(&g_ui32USBFlags, FLAG_CONNECTED) = 0;
            g_eKeyboardState = KEYBOARD_STATE_UNCONFIGURED;


        }

        //
        // We receive this event every time the host acknowledges transmission
        // of a report. It is used here purely as a way of determining whether
        // the host is still talking to us or not.
        //
        case USB_EVENT_TX_COMPLETE:
        {
            //
            // Enter the idle state since we finished sending something.
            //
            g_eKeyboardState = KEYBOARD_STATE_IDLE;
            break;
        }

        //
        // This event indicates that the host has suspended the USB bus.
        //
        case USB_EVENT_SUSPEND:
        {
            HWREGBITW(&g_ui32USBFlags, FLAG_SUSPENDED) = 1;
            break;
        }

        //
        // This event signals that the host has resumed signaling on the bus.
        //
        case USB_EVENT_RESUME:
        {
            HWREGBITW(&g_ui32USBFlags, FLAG_SUSPENDED) = 0;
            break;
        }

        //
        // This event indicates that the host has sent us an Output or
        // Feature report and that the report is now in the buffer we provided
        // on the previous USBD_HID_EVENT_GET_REPORT_BUFFER callback.
        //
        case USBD_HID_KEYB_EVENT_SET_LEDS:
        {
            break;
        }

        //
        // We ignore all other events.
        //
        default:
        {
            break;
        }
    }

    return(0);
}

//***************************************************************************
//
// Wait for a period of time for the state to become idle.
//
// \param ui32TimeoutTick is the number of system ticks to wait before
// declaring a timeout and returning \b false.
//
// This function polls the current keyboard state for ui32TimeoutTicks system
// ticks waiting for it to become idle.  If the state becomes idle, the
// function returns true.  If it ui32TimeoutTicks occur prior to the state
// becoming idle, false is returned to indicate a timeout.
//
// \return Returns \b true on success or \b false on timeout.
//
//***************************************************************************
bool
KeyboardWaitForSendIdle(uint_fast32_t ui32TimeoutTicks)
{
    uint32_t ui32Start;
    uint32_t ui32Now;
    uint32_t ui32Elapsed;

    ui32Start = g_ui32SysTickCount;
    ui32Elapsed = 0;

    while(ui32Elapsed < ui32TimeoutTicks)
    {
        //
        // Is the keyboard is idle, return immediately.
        //
        if(g_eKeyboardState == KEYBOARD_STATE_IDLE)
        {
            return(true);
        }

        //
        // Determine how much time has elapsed since we started waiting.  This
        // should be safe across a wrap of g_ui32SysTickCount.
        //
        ui32Now = g_ui32SysTickCount;
        ui32Elapsed = ((ui32Start < ui32Now) ? (ui32Now - ui32Start) :
                     (((uint32_t)0xFFFFFFFF - ui32Start) + ui32Now + 1));
    }

    //
    // If we get here, we timed out so return a bad return code to let the
    // caller know.
    //
    return(false);
}

//****************************************************************************
//
// This function will send a KeyState change to the USB library and wait for
// the transmission to complete.
//
//****************************************************************************
uint32_t KeyboardStateChange(uint8_t ui8Modifiers, uint8_t ui8Usage,
                             bool bPressed)
{
    uint32_t ui32RetCode;

    //
    // Send the Key state change to the
    //
    g_eKeyboardState = KEYBOARD_STATE_SENDING;
    ui32RetCode = USBDHIDKeyboardKeyStateChange((void *)&g_sKeyboardDevice,
                                                ui8Modifiers, ui8Usage,
                                                bPressed);

    if(ui32RetCode == KEYB_SUCCESS)
    {
        //
        // Wait until the key press message has been sent.
        //
        if(!KeyboardWaitForSendIdle(MAX_SEND_DELAY))
        {
            HWREGBITW(&g_ui32USBFlags, FLAG_CONNECTED) = 0;


        }
    }

    return (ui32RetCode);
}

//****************************************************************************
//
// Primary keyboard application function.  This function translates the Gesture
// states provided by the motion system into keyboard events to emulate certain
// application functions.
//
// A quick lift will simulate an ALT + TAB. While lifted a twist left or right
// will select amongst the open windows presented in the ALT + TAB dialog. A
// quick down motion will return to the idle state and ready for mousing.
//
// While in the idle state a quick twist about the Z axis will page up or page
// down the current window depending on direction of rotation.  A sharp
// horizontal left or right acceleration will send a CTRL + or CTRL - depending
// on direction.
//
// Roll and Pitch while idle move the mouse cursor.  See MouseMoveHandler.
//
//****************************************************************************
void
KeyboardMain(void)
{
    bool bKeyHold, bModifierHold;
    uint8_t ui8Key, ui8Modifiers;

    //
    // Check if the keyboard is in the suspended state.
    //
    if(HWREGBITW(&g_ui32USBFlags, FLAG_SUSPENDED) == 1)
    {
        //
        // We are connected but keyboard is suspended so do wake request.
        //
        USBDHIDKeyboardRemoteWakeupRequest((void *)&g_sKeyboardDevice);
    }
    else
    {
        if(MotionKeyboardGet(&ui8Modifiers, &ui8Key, &bModifierHold,
                             &bKeyHold))
        {
            //
            // Send the Keyboard Packet button presses.
            //
            if(KeyboardStateChange(ui8Modifiers, ui8Key, true) != KEYB_SUCCESS)
            {
                return;
            }

            //
            // Release the key and modifier depending on the hold state that
            // was returned.
            //
            ROM_SysCtlDelay(ROM_SysCtlClockGet() / (100 * 3));

            if(KeyboardStateChange(bModifierHold ? ui8Modifiers : 0,
                                   ui8Key, bKeyHold) != KEYB_SUCCESS)
            {
                return;
            }
        }
    }
}

//****************************************************************************
//
// Generic event handler for the composite device. This should handle events
// that come in for endpoint zero of our composite device.
//
//****************************************************************************
uint32_t
EventHandler(void *pvCBData, uint32_t ui32Event, uint32_t ui32MsgData,
             void *pvMsgData)
{
    switch(ui32Event)
    {
        //
        // The host has connected to us and configured the device.
        //
        case USB_EVENT_CONNECTED:
        {
            //
            // Now connected.
            //
            HWREGBITW(&g_ui32USBFlags, FLAG_CONNECTED) = 1;



            break;
        }

        //
        // Handle the disconnect state.
        //
        case USB_EVENT_DISCONNECTED:
        {
            //
            // No longer connected.
            //
            HWREGBITW(&g_ui32USBFlags, FLAG_CONNECTED) = 0;


            break;
        }

        default:
        {
            break;
        }
    }

    return(0);
}
