#include "mouse_state.h"

int8_t* mousePredictions;


int8_t* getPredictions(){
    return mousePredictions;
}

void setPredictions(int8_t* predictions){
    mousePredictions = predictions;
}

